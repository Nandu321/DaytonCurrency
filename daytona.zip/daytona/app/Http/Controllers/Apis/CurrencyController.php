<?php

namespace App\Http\Controllers\Apis;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use App\models\UserActions;
use App\models\CurrencyConversion;

class CurrencyController extends Controller {

    protected $auth_id;
    protected $auth_token;
    protected $auth_email;

    public function index() {
        return response()->make(['error' => 'Accessing the page or resource you were trying to reach '
                    . 'is absolutely forbidden for some reason'], 400);
    }

    public function create() {
        return response()->make(['error' => 'Accessing the page or resource you were trying to reach '
                    . 'is absolutely forbidden for some reason'], 400);
    }

    public function store() {
        return response()->make(['error' => 'Accessing the page or resource you were trying to reach '
                    . 'is absolutely forbidden for some reason'], 400);
    }

    public function show() {
        return response()->make(['error' => 'Accessing the page or resource you were trying to reach '
                    . 'is absolutely forbidden for some reason'], 400);
    }

    public function destroy() {
        return response()->make(['error' => 'Accessing the page or resource you were trying to reach '
                    . 'is absolutely forbidden for some reason'], 400);
    }

    public function __construct() {
        $this->auth_id = Auth::guard('api')->user()->id;
        $this->auth_token = Auth::guard('api')->user()->api_token;
        $this->auth_email = Auth::guard('api')->user()->email;
    }

    public function add_currency(Request $request) {
        $data = $request->all();
        $currency_code = $request->currency_code;
        unset($data['api_token']);
        $get_currency = CurrencyConversion::get_currency($currency_code);
        if (!$get_currency) {
            $currency_result = CurrencyConversion::create($data);
        } else {
            $currency_result = CurrencyConversion::where('currency_code', $currency_code)
                    ->update($data);
        }
        $data['action'] = "add";
        $data['user_id'] = $this->auth_id;
        $user_actions = UserActions::create($data);

        return response()->json(['STATUS_CODE' => 1, 'currency_result' => $currency_result]);
    }

    public function currency_list(Request $request) {

        $aColumns = array('id', 'currency_code', 'currency_name', 'conversion_rate');

        /* Indexed column (used for fast and accurate table cardinality) */
        $sIndexColumn = "id";
        /* DB table to use */
        $sTable = "currency_conversion";
        $gaSql['user'] = \Config::get('database.connections.mysql.username');
        $gaSql['password'] = \Config::get('database.connections.mysql.password');
        $gaSql['db'] = \Config::get('database.connections.mysql.database');
        $gaSql['server'] = \Config::get('database.connections.mysql.host');

        /*         * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
         * If you just want to use the basic configuration for DataTables with PHP server-side, there is
         * no need to edit below this line
         */
        /*
         * Local functions
         */

        function fatal_error($sErrorMessage = '') {
            header($_SERVER['SERVER_PROTOCOL'] . ' 500 Internal Server Error');
            die($sErrorMessage);
        }

        /*
         * MySQL connection
         */
        if (!$gaSql['link'] = mysqli_connect($gaSql['server'], $gaSql['user'], $gaSql['password'], $gaSql['db'])) {
            fatal_error('Could not open connection to server');
        }
//    print_r($gaSql);exit;
        if (!mysqli_select_db($gaSql['link'], $gaSql['db'])) {
            fatal_error('Could not select database ');
        }

        /*
         * Paging
         */
        $sLimit = "";
        if (isset($_GET['iDisplayStart']) && $_GET['iDisplayLength'] != '-1') {
            $sLimit = "LIMIT " . intval($_GET['iDisplayStart']) . ", " .
                    intval($_GET['iDisplayLength']);
        }

        /*
         * Ordering
         */
        $sOrder = "";
        if (isset($_GET['iSortCol_0'])) {
            $sOrder = "ORDER BY  ";
            for ($i = 0; $i < intval($_GET['iSortingCols']); $i++) {
                if ($_GET['bSortable_' . intval($_GET['iSortCol_' . $i])] == "true") {
                    $sOrder .= $aColumns[intval($_GET['iSortCol_' . $i])] . "
                    " . ($_GET['sSortDir_' . $i] === 'asc' ? 'asc' : 'desc') . ", ";
                }
            }

            $sOrder = substr_replace($sOrder, "", -2);
            if ($sOrder == "ORDER BY") {
                $sOrder = "";
            }
        }
        /*
         * Filtering
         * NOTE this does not match the built-in DataTables filtering which does it
         * word by word on any field. It's possible to do here, but concerned about efficiency
         * on very large tables, and MySQL's regex functionality is very limited
         */
        $sWhere = "";
        if (isset($_GET['sSearch']) && $_GET['sSearch'] != "") {
            $sWhere = "WHERE (";
            for ($i = 0; $i < count($aColumns); $i++) {
                if (isset($_GET['bSearchable_' . $i]) && $_GET['bSearchable_' . $i] == "true") {
                    $sWhere .= $aColumns[$i] . " LIKE '%" . mysqli_real_escape_string($gaSql['link'], $_GET['sSearch']) . "%' OR ";
                }
            }
            $sWhere = substr_replace($sWhere, "", -3);
            $sWhere .= ')';
        }
        /* Individual column filtering */
        for ($i = 0; $i < count($aColumns); $i++) {
            if (isset($_GET['bSearchable_' . $i]) && $_GET['bSearchable_' . $i] == "true" && $_GET['sSearch_' . $i] != '') {
                if ($sWhere == "") {
                    $sWhere = "WHERE ";
                } else {
                    $sWhere .= " AND ";
                }
                $sWhere .= $aColumns[$i] . " LIKE '%" . mysqli_real_escape_string($gaSql['link'], $_GET['sSearch_' . $i]) . "%' ";
            }
        }



        if ($sWhere == "") {
            $sWhere = "WHERE $sTable.is_active=1";
        } else {
            $sWhere .= " AND $sTable.is_active=1 ";
        }


        $sQuery = "
        SELECT  id,currency_code, currency_name, conversion_rate FROM $sTable   
        $sWhere
        $sOrder
        $sLimit
    ";
        $rResult = mysqli_query($gaSql['link'], $sQuery) or fatal_error('MySQL Error: ' . mysqli_error($gaSql['link']));

        /* Data set length after filtering */
        $sQuery = "
        SELECT FOUND_ROWS()
    ";
        $rResultFilterTotal = mysqli_query($gaSql['link'], $sQuery) or fatal_error('MySQL Error: ' . mysqli_error($gaSql['link']));
        $aResultFilterTotal = mysqli_fetch_array($rResultFilterTotal);
        $iFilteredTotal = $aResultFilterTotal[0];

        /* Total data set length */
        $sQuery = "
        SELECT COUNT(" . $sIndexColumn . ")
        FROM   $sTable
    ";
        $rResultTotal = mysqli_query($gaSql['link'], $sQuery) or fatal_error('MySQL Error: ' . mysqli_error($gaSql['link']));
        $aResultTotal = mysqli_fetch_array($rResultTotal);
        $iTotal = $aResultTotal[0];

        /*
         * Output
         */
        $output = array(
            "sEcho" => (isset($_GET['sEcho'])) ? intval($_GET['sEcho']) : '',
            "iTotalRecords" => $iTotal,
            "iTotalDisplayRecords" => $iFilteredTotal,
            "aaData" => array(),
        );
        $sno = (isset($_GET['iDisplayStart'])) ? intval($_GET['iDisplayStart']) + 1 : '';
        while ($aRow = mysqli_fetch_array($rResult)) {
            $row = array();
            for ($i = 0; $i < count($aColumns); $i++) {
                if ($aColumns[$i] == "version") {
                    /* Special output formatting for 'version' column */
                    $row[] = ($aRow[$aColumns[$i]] == "0") ? '-' : $aRow[$aColumns[$i]];
                } else if ($aColumns[$i] != ' ') {
                    /* General output */
                    $row[] = $aRow[$aColumns[$i]];
                }
            }
            $id = $aRow['id'];
            $currency_code = $aRow['currency_code'];
            $currency_name = $aRow['currency_name'];
            $conversion_rate = $aRow['conversion_rate'];

            $row = array(0 => $sno + 1,
                1 => "<div style='text-align:center'>$currency_code</div>",
                2 => "<div style='text-align:center'>$currency_name</div>",
                3 => "<div style='text-align:center'>$conversion_rate</div>",
                4 => "<div style='text-align:center'>
                <a href='#'><i class='fa fa-2x fa-pencil-square'></i></a>
                <a href='#' style='padding-left:5px'><i class='fa fa-2x fa-trash'></i></a></div>",
            );
            $sno++;
            $output['aaData'][] = $row;
        }
//          var_dump($output);
//            exit();
        return $output;
    }

}
