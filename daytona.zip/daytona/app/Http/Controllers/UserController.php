<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller {

//    public function __construct() {
//        
//    }

    public function authcheck(Request $request) {
        $email = $request->email;
        $password = $request->password;
        $data = ['email' => $email, 'password' => $password];
        $userauth = Auth::attempt($data);
        $api_token = str_random(60);
        
        \App\User::where('email', $email)->update(['api_token' => $api_token]);
        
        return response()->json(['STATUS_CODE' => 1, 'userauth' => $userauth]);
    }

}
