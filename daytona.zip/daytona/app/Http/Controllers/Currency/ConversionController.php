<?php

namespace App\Http\Controllers\Currency;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

class ConversionController extends Controller {

    public function index(Request $request) {
        $api_token = Auth::user()->api_token;
        $get_currencies = \App\models\CurrencyConversion::get_currencies();
        return view('currency.conversion', ['api_token' => $api_token,'get_currencies' => $get_currencies]);
    }

    //Currency conversion
    public function conversion(Request $request) {
        $api_token = Auth::user()->api_token;
        return view('currency.conversion', ['api_token' => $api_token]);
    }

    //Manage the currency
    public function manage(Request $request) {
        $api_token = Auth::user()->api_token;
        return view('currency.manage', ['api_token' => $api_token]);
    }

    //View the currencies
    public function view(Request $request) {
        return view('currency.view');
    }

}
