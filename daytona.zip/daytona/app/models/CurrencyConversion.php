<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class CurrencyConversion extends Model {

    public $table = "currency_conversion";
    public $fillable = ['id', 'currency_code', 'currency_name', 'conversion_rate', 'comments',
        'is_active', 'is_delete', 'created_at', 'updated_at'];
    
    
    public static function get_currency($currency_code){
        $result = self::where('currency_code', $currency_code)
                ->first(['id', 'currency_code', 'currency_name', 'conversion_rate']);
        return $result;
    }
    
    public static function get_currencies(){
        $result = self::where('is_active', 1)
                ->get(['id', 'currency_code', 'currency_name', 'conversion_rate']);
        return $result;
    }

}
