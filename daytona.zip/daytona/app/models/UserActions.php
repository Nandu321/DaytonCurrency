<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class UserActions extends Model
{
    public $table = "user_actions";
    public $fillable = ['id', 'user_id', 'currency_code', 'currency_name',
        'conversion_rate', 'action', 'is_active', 'is_delete', 'created_at', 'updated_at'];

}
