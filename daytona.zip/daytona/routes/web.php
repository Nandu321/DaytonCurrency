<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('signin');
});

Route::group(['prefix' => "currency",'namespace' => 'Currency'],function(){
    Route::resource("/", "ConversionController");
    Route::get("manage", "ConversionController@manage");
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::post('authcheck', 'UserController@authcheck');
