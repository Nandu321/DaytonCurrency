<!DOCTYPE html>
<html>
    <head>
        <title>Manage Currencies</title>
        <meta name="_token" content="{{csrf_token()}}" />   
        <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
        <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
        <script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
        <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
        <link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet" id="dt-css">
        <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" id="dt-css">
        <script>
$(function () {
    $(".addcurrency").on("click", function () {
        var api_token = $("#api_token").val();
        var data_url = $(this).attr('data-url') + "/api/add_currency";
        var data = $("form[name='currencyform']").serialize();

        data["api_token"] = api_token;
        $("#success_msg").html("<span style='color: green;'><a href=''><i class='fa fa-spinner fa-spin'></i></a> Please wait ...</span>");
        $.ajax({
            url: data_url,
            type: 'POST',
            data: data,
            cache: false,
            headers: {'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')},
            success: function (data, textStatus, jqXHR) {
                $("#success_msg").html('<span style="color: green;">Currency added successfully!</span>')
                return false;
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(errorThrown)
                return false;
            }

        })
    });

    var durl = $('#example').attr('data-url');
    var api_token = $("#api_token").val()
    var dt = $('#example').dataTable({
        "bScrollCollapse": true,
        "sDom": '<"top"iflp<"clear">>rt',
        "bProcessing": true,
        "bFilter": false,
        "bLengthChange": false,
        "iDisplayLength": 25,
        "sPaginationType": "simple_numbers",
        "info": false,
        bSortable: true,
        bRetrieve: true,
        "sAjaxSource": durl + '/api/currency_list?api_token=' + api_token,
        "fnServerParams": function (aoData, fnCallback) {
            aoData.push({"name": "email", "value": $("#email").val()}),
                    aoData.push({"name": "status_type", "value": $("#status_type").val()})
        },
        "fnRowCallback": function (nRow, aData, iDisplayIndex) {
            var oSettings = dt.fnSettings();
            $("td:first", nRow).html(oSettings._iDisplayStart + iDisplayIndex + 1);

            return nRow;
        },
        "oLanguage": {
            "sZeroRecords": "<p style='color:#555;font-size:15px;'>No data.</p>"
        },
        "initComplete": function (settings, json) {
            //alert('DataTables has finished its initialisation.');
            $('div.dt_loading').remove();
        }
    });
});
function isEmail(email) {
    var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    return regex.test(email);
}
        </script>
        <style>
            .panel-info {
                border-color: #bce8f1;
                margin: 15px;
                padding: 20px;
            }
            .topheader{
                margin: 5px;
                padding: 10px 5px 1px 5px;
                background: lightblue;
                font-weight: bold;
            }
            .fa-2x {
                font-size: 1.5em;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div id="loginbox" style="margin-top:50px;" class="mainbox col-md-9 col-md-offset-1 col-sm-8 col-sm-offset-2">                    
                <div class="panel panel-info" >
                    <div class="topheader"><p>Currency management</p></div>
                    <div id="success_msg" style="text-align: center;font-weight: bold"></div>
                    <form name="currencyform" action="#" method="POST">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="currency_name">Currency name</label>
                                    <input type="text" class="form-control" name="currency_name" id="currency_name" placeholder="Currency name">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="currency_code">Currency code</label>
                                    <input type="text" class="form-control" name="currency_code" id="currency_code" placeholder="Currency code">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="conversion_rate">Conversion rate to the USD</label>
                                    <input type="text" class="form-control" name="conversion_rate" id="conversion_rate" placeholder="Conversion rate to the USD">
                                </div>
                            </div>
                            <div style="margin-top:10px; text-align: center" class="form-group">
                                <div class="col-sm-12 controls">
                                    <a id="btn-login" data-url="{{url('')}}" href="#" class="btn btn-success addcurrency">ADD</a>
                                    <a id="btn-login" data-url="{{url('')}}" href="{{url('/currency/manage')}}" class="btn btn-danger">RESET</a>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" name="api_token" id="api_token" value="{{$api_token}}" />
                    </form>

                    <div class="dt_loading"><i style="width:100%;text-align:center;margin-top:20px;color:#f1292b" class="fa-2x fa fa-spinner fa-spin"></i></div>
                    <div class="get_filter_result" >
                        <div class="col-md-12" style="margin-top: 45px">
                            <table id="example" data-url="{{url('')}}" class="table table-hover table-responsive desk-plan">
                                <thead>
                                    <tr class="bg-v-333">
                                        <th>SL</th>
                                        <th>CURRENCY NAME</th>
                                        <th>CURRENCY CODE</th>
                                        <th>CONVERSION RATE</th>
                                        <th>ACTIONS</th>
                                    </tr>
                                </thead>                                  
                            </table>
                        </div>
                    </div>   
                </div>
            </div>
        </div>
    </body>
</html>