<!DOCTYPE html>
<html>
    <head>
        <meta name="_token" content="{{csrf_token()}}" />   
        <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
        <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
        <script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
        <script>
$(function () {
    $(".signin").on("click", function () {
        var email = $("#login-username").val();
        var password = $("#login-password").val();
        var data_url = $(this).attr('data-url') + "/authcheck";
        if (isEmail(email)) {
            $("#validemail").html("");
        } else {
            $("#validemail").html("Error: Please enter valid email!");
            return false;
        }
        var data = {
            "email": email,
            "password": password
        };
        $("#login_error").html("<span style='color: green;'><a href=''><i class='fa fa-spinner fa-spin'></i></a> Please wait ...</span>")

        $.ajax({
            url: data_url,
            type: 'POST',
            data: data,
            cache: false,
            headers: {'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')},
            success: function (data, textStatus, jqXHR) {
                if (data.userauth == 1) {
                    window.location = "currency/conversion";
                } else {
                    $("#login_error").html('<span style="color: #f1292b;">Invalid Credentials.Please enter correct details</span>')
                    return false;
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(errorThrown)
                return false;
            }

        })
    });
});
function isEmail(email) {
    var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    return regex.test(email);
}
        </script>
        <style>
            .panel-info {
                border-color: #bce8f1;
                margin: 15px;
                padding: 20px;
            }
            .topheader{
                margin: 5px;
                padding: 10px 5px 1px 5px;
                background: lightblue;
                font-weight: bold;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div id="loginbox" style="margin-top:50px;" class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">                    
                <div class="panel panel-info" >
                    <div class="topheader"><p>Currency management</p></div>
                    <form>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="fromc">FROM</label>
                                    <select class="form-control" id="fromc">
                                        <option selected>Choose...</option>
                                        <option value="1">One</option>
                                        <option value="2">Two</option>
                                        <option value="3">Three</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="toc">TO</label>
                                    <select class="form-control" id="toc">
                                        <option selected>Choose...</option>
                                        <option value="1">One</option>
                                        <option value="2">Two</option>
                                        <option value="3">Three</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="inputvalue">Input</label>
                                    <input type="text" class="form-control" id="inputvalue" placeholder="Input">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="outputvalue">Output</label>
                                    <input type="text" class="form-control" id="outputvalue" placeholder="Output">
                                </div>
                            </div>
                            <div style="margin-top:10px; text-align: center" class="form-group">
                                <div class="col-sm-12 controls">
                                    <a id="btn-login" data-url="{{url('')}}" href="#" class="btn btn-success signin">Currency Manage</a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </body>
</html>